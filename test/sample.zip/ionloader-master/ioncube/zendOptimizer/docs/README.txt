                       Zend Optimizer(TM), version 3.3
                       ===============================


This package contains the Zend Optimizer from Zend Technologies Ltd.

Installation
-=-=-=-=-=-=

For Installation Instructions, how-to-use instructions, and support information, please see the
Zend Optimizer User Guide, named Zend_Optimizer_User_Guide.pdf, which you will find in the
data/doc/ folder under Unix packages and in the "Start" menu on Windows installation. 
For more technical information on the Zend Optimizer.


Getting Support
-=-=-=-=-=-=-=-

If you have purchased the Zend Guard, you can submit free questions about Zend Optimizer setup and installation support through Zend Support.

Answers to technical and operating system related questions can be found in the Zend Knowledge Base. 
Here you will find a repository of articles that address know issues and how to deal with them:
http://www.zend.com/support/knowledgebase.php


For issues other than technical support, email us at: support@zend.com

Otherwise, you can access one of the Zend forums: http://www.zend.com/forums/

Thank you for using the Zend Optimizer!

Zend Technologies Ltd.

http://www.zend.com/

# ionloader
This is a decrypter for ioncode written in .Net and forked from another source.
